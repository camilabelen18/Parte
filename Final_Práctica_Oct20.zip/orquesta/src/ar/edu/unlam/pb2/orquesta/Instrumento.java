package ar.edu.unlam.pb2.orquesta;

public class Instrumento {
	private Integer tono;

	public String tocar();
}
