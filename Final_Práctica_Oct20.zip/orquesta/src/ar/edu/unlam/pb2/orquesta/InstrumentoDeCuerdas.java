package ar.edu.unlam.pb2.orquesta;

public class InstrumentoDeCuerdas {
private Integer cantidadDeCuerdas;

public Integer getCantidadDeCuerdas() {
	return cantidadDeCuerdas;
}

public void setCantidadDeCuerdas(Integer cantidadDeCuerdas) {
	this.cantidadDeCuerdas = cantidadDeCuerdas;
}

}
