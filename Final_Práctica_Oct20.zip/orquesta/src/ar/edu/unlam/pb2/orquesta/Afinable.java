package ar.edu.unlam.pb2.orquesta;

public class Afinable {
	public String afinar();
}
