package ar.edu.unlam.pb2.orquesta;

import java.util.Collection;

public class Orquesta {
	private List<Instrumento> instrumentos;

	public Orquesta() {

	}

	public void agregarInstrumento(Instrumento instrumento) {

	}

	public List<Instrumento> obtenerInstrumentosDeCuerdas() {

	}

	public List<Instrumento> obtenerInstrumentosDeViento() {

	}

	public Boolean agregarInstrumento(){
		
	}
	public void tocarVientos() {

	}

	public void tocarCuerdas() {

	}

	public void tocar() {

	}
}
