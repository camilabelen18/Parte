package ar.edu.unlam.pb2.orquesta;

public class OrquestTest {
	@Test
	public void testQueTodosLosInstrumentosSePuedanTocar() {

	}
	@Test
	public void testQueUnAfinadorPuedaAfinarSoloAfinables(){
		
	}
	@Test
	public void testQueToquenLosInstrumentosDeViento(){
		
	}
	@Test
	public void testQueToquenLosInstrumentosDeCuerdas(){
		
	}
}
